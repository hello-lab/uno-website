
let cards = ['wild', '+2r', '+4', 'reverser', 'skipr', '1r', '2r', '3r', '4r', '5r', '6r', '7r', '8r', '9r', '+2g', 'reverseg', 'skipg', '1g', '2g', '3g', '5g', '6g', '7g', '8g', '9g', '+2b', 'reverseb', 'skipb', '1b', '2b', '3b', '5b', '6b', '7b', '8b', '9b', '+2y', 'reversey', 'skipy', '1y', '2y', '3y', '5y', '6y', '7y', '8y', '9y']

function shuffle(n) {
	var cardse = JSON.parse(JSON.stringify(cards))
	switch (n) {
		case 2:
			p1 = []
			p2 = []
			p3 = new Array(52);
			p4 = new Array(52);
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cardse.length)
				a = cardse[c]
				cardse.splice(c, 1)

				p1.push(a)

				d = Math.floor(Math.random() * cardse.length)
				b = cardse[d]
				cardse.splice(d, 1)

				p2.push(b)
			}
			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };
		case 3:
			p1 = [];
			p2 = [];
			p3 = [];
			p4 = new Array(52);
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cardse.length);
				a = cardse[c];
				cardse.splice(c, 1);
				p1.push(a);

				d = Math.floor(Math.random() * cardse.length);
				b = cardse[d];
				cardse.splice(d, 1);
				p2.push(b);

				e = Math.floor(Math.random() * cardse.length);
				f = cardse[e];
				cardse.splice(e, 1);
				p3.push(f);
			}
			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };
		case 4:
			p1 = [];
			p2 = [];
			p3 = [];
			p4 = [];
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cardse.length);
				a = cardse[c];
				cardse.splice(c, 1);
				p1.push(a);

				d = Math.floor(Math.random() * cardse.length);
				b = cardse[d];
				cardse.splice(d, 1);
				p2.push(b);

				e = Math.floor(Math.random() * cardse.length);
				f = cardse[e];
				cardse.splice(e, 1);
				p3.push(f);

				g = Math.floor(Math.random() * cardse.length);
				h = cardse[g];
				cardse.splice(g, 1);
				p4.push(h);
			}

			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };

	}

}


function shuff(n) {
	var cardse = JSON.parse(JSON.stringify(cards))
	console.log(n)
	plcards = shuffle(n)
	 let plc = []
	restdeck = []

	for (i = 0; i < 4; i++) {
		console.log(plcards["p" + (i + 1)].length)
		if (plcards["p" + (i + 1)].length == 7)
			plc=plc.concat(plcards["p" + (i + 1)])
	}

	console.log(plc)
	for (i = 0; (cards.length - plc.length) != restdeck.length;) {

		c = Math.floor(Math.random() * cardse.length);
		randc = cardse[c]

		if (plc.indexOf(randc) == -1&&  restdeck.indexOf(randc)==-1) {

			restdeck.push(randc)
			cardse.splice(c, 1)
		}
	}
	firstcard = restdeck.pop()


	return { "plcards": plcards, "restdeck": restdeck, "firstcard": firstcard }
}


	console.log(shuff(2))