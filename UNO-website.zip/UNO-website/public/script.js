cardss = ['wildr', '+2r', '+4r', 'reverser', 'skipr', '1r', '2r', '3r', '4r', '5r', '6r', '7r', '8r', '9r', 'wildg', '+2g', '+4g', 'reverseg', 'skipg', '1g', '2g', '3g', '4g', '5g', '6g', '7g', '8g', '9g', 'wildb', '+2b', '+4b', 'reverseb', 'skipb', '1b', '2b', '3b', '4b', '5b', '6b', '7b', '8b', '9b', 'wildy', '+2y', '+4y', 'reversey', 'skipy', '1y', '2y', '3y', '4y', '5y', '6y', '7y', '8y', '9y']
cards = JSON.parse(JSON.stringify(cardss))
function shuffle(n) {
	switch (n) {
		case 2:
			p1 = []
			p2 = []
			p3 = new Array(1000);
			p4 = new Array(1000);
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cards.length)
				a = cards[c]
				cards.splice(c, 1)

				p1.push(a)

				d = Math.floor(Math.random() * cards.length)
				b = cards[d]
				cards.splice(d, 1)

				p2.push(b)
			}
			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };
		case 3:
			p1 = [];
			p2 = [];
			p3 = [];
			p4 = new Array(1000);
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cards.length);
				a = cards[c];
				cards.splice(c, 1);
				p1.push(a);

				d = Math.floor(Math.random() * cards.length);
				b = cards[d];
				cards.splice(d, 1);
				p2.push(b);

				e = Math.floor(Math.random() * cards.length);
				f = cards[e];
				cards.splice(e, 1);
				p3.push(f);
			}
			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };
		case 4:
			p1 = [];
			p2 = [];
			p3 = [];
			p4 = [];
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cards.length);
				a = cards[c];
				cards.splice(c, 1);
				p1.push(a);

				d = Math.floor(Math.random() * cards.length);
				b = cards[d];
				cards.splice(d, 1);
				p2.push(b);

				e = Math.floor(Math.random() * cards.length);
				f = cards[e];
				cards.splice(e, 1);
				p3.push(f);

				g = Math.floor(Math.random() * cards.length);
				h = cards[g];
				cards.splice(g, 1);
				p4.push(h);
			}

			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };

	}

}

plcards = shuffle(2)
plc = []
restdeck = []
for (i = 0; i < 4; i++) {
	if (plcards["p"+(i+1)].length==7)
	plc += (plcards["p" + (i + 1)])
}
console.log(plc)
for (i = 0; i < cards.length; i++) {

	c = Math.floor(Math.random() * cards.length);
	randc = cards[c]
	if (plc.indexOf(randc) == -1)
		restdeck.push(randc)
}
firstcard = restdeck.pop()


console.log( plcards.p1)
console.log(firstcard)
	

while (plcards.p1.length > 0 && plcards.p2.length > 0 && plcards.p3.length > 0 && plcards.p4.length > 0) {
	console.log(p1.length)

	//input
	var input = prompt("p1 turn");

	if (firstcard[0] == input[0] || firstcard[firstcard.length-1] == input[input.length-1]) {
		firstcard = input
		plcards.p1 = remove(plcards.p1, input)
	}
	else {
		plcards.p1.push(restdeck.pop())
	}
	console.log(plcards.p1)
	console.log(firstcard)
}




function addkard() {

	}

function remove(arr, name) {
	i = arr.indexOf(name)
	arr.splice(i , 1)
	return arr
}