/* eslint-disable no-undef */
const express = require('express')
const app = express()
const port = 3000
const bodyParser = require('body-parser')

let cards = ['wild', '+2r', '+4', 'reverser', 'skipr', '1r', '2r', '3r', '4r', '5r', '6r', '7r', '8r', '9r', '+2g', 'reverseg', 'skipg', '1g', '2g', '3g', '5g', '6g', '7g', '8g', '9g', '+2b', 'reverseb', 'skipb', '1b', '2b', '3b', '5b', '6b', '7b', '8b', '9b', '+2y', 'reversey', 'skipy', '1y', '2y', '3y', '5y', '6y', '7y', '8y', '9y']
console.log(cards.length)
const mysql = require('mysql');

// Create a connection to the database
const connection = mysql.createConnection({
	host: 'localhost',
	user: 'root',
	password: 'niyosan42',
	database: 'uno'
})
connection.connect((err) => {
	if (err) {
		console.error('Error connecting to database: ' + err.stack);
		return;
	}

	console.log('Connected to database as id ' + connection.threadId);
});


connection.query(`CREATE TABLE IF NOT EXISTS uno2 (
  id INT AUTO_INCREMENT PRIMARY KEY,
  nopl INT,
  state VARCHAR(255),
  p1 JSON,
  p2 JSON,
  p3 JSON,
  p4 JSON,
  p1id VARCHAR(255),
  p2id VARCHAR(255),
  p3id VARCHAR(255),
  p4id VARCHAR(255),
  restdeck JSON,
  firstcard VARCHAR(255),
  currentp VARCHAR(255),
  nextp VARCHAR(255),
  roomid VARCHAR(255)
)`, (error, results, fields) => {
	if (error) {
		console.error('Error creating table: ' + error.message);
	} else {
		console.log('Table created successfully');
	}
});


const fs = require('node:fs');



data = fs.readFileSync('index.html', 'utf8');
    app.get('/', (req, res) => {
    res.send(data)
    })

app.use(bodyParser.json()) // for parsing application/json
app.use(bodyParser.urlencoded({ extended: true })) // for parsing application/x-www-form-urlencoded


/*
app.post('/', (req, res) => {
	let a = req.body.nopl
	console.log(req.body) 
	if (req.body.roomid == "")
		req.body.roomid = Math.floor(Math.random() * 10000)
		
	crds=shuff(a)
	 data = {
		p1: JSON.stringify(crds.plcards.p1),
		p2: JSON.stringify(crds.plcards.p2),
		p3: JSON.stringify(crds.plcards.p3),
		p4: JSON.stringify(crds.plcards.p4),
		nopl: a,
		state: "pregame",
		p1id: "",
		p2id: "",
		p3id: "",
		p4id: "",
		restdeck: JSON.stringify(crds.restdeck),
		firstcard:crds.firstcard,
		currentp: "p1",
		nextp: "p2",
		roomid: req.body.roomid
	};

	


	res.send('')
})
*/
app.get('/gen_name', (req, res) => {

	res.send({ userId:String.fromCharCode(Math.floor(Math.random() * 1000)) + Math.floor(Math.random() * 1000000) })

})

app.post('/gen_room', (req, res) => {

	let a = req.body.nopl
	console.log(a)
		rmid= Math.floor(Math.random() * 1000000)

	crds = shuff(a)

	data = {
		p1: JSON.stringify(crds.plcards.p1),
		p2: JSON.stringify(crds.plcards.p2),
		p3: JSON.stringify(crds.plcards.p3),
		p4: JSON.stringify(crds.plcards.p4),
		nopl: a,
		state: "pregame",
		p1id: req.body.userId,
		p2id: "",
		p3id: "",
		p4id: "",
		restdeck: JSON.stringify(crds.restdeck),
		firstcard: crds.firstcard,
		currentp: req.body.userId,
		nextp: "p1",
		roomid: rmid
	};


	

	connection.query('INSERT INTO uno2 SET ?', data, (error, results, fields) => {
		if (error) {
			console.error('Error inserting data: ' + error.message);
		} else {
			console.log('Data inserted successfully');
		}
	}); 
	res.send({"roomid":rmid})
	
})

app.post('/join_room', (req, res) => {

	 sql = `SELECT * FROM uno2 WHERE ?? = ?`;
	values = ["roomid", req.body.rmid];

	connection.query(sql, values, (err, result) => {
		if (err) {
			console.error('Error searching for row:', err);
			return;
		}
		result = result[0]
		//console.log(result.p2id)
		if (result.p2id == '')

			result.p2id = req.body.userId
		else if (result.p3id=='')
			result.p3id = req.body.userId
		else if (result.p4id=='')
			result.p4id = req.body.userId



			console.log(result)
		 sql = `UPDATE uno2 SET ? WHERE ?? = ?`;
		 values = [result, "roomid", req.body.rmid];

		connection.query(sql, values, (err, result) => {
			if (err) {
				console.error('Error updating column:', err);
				return;
			}
			console.log('Column updated successfully');
		});
	})

		

	res.send({body:"connected to room "+req.body.rmid,rmid:req.body.rmid})

	
  })


app.post('/btnclik', (req, res) => {
	rmid= (req.body.rmid)
	sql = `SELECT * FROM uno2 WHERE ?? = ?`;
	values = ["roomid", rmid];

	connection.query(sql, values, (err, result) => {
		if (err) {
			console.error('Error searching for row:', err);
			return;
		}
		result = result[0]
		topcrd = result.firstcard
		plcard = req.body.card
		nextpl=""
		curpl = result.nextp
		restcard = JSON.parse(result.restdeck)
		switch (result.nopl) {

			case 2:
				console.log('heyooo')
				if (curpl[1] == '2') {
					nextpl = "p1"
					console.log('heyooo')
				}

				else {
					nextpl = "p" + (Number.parseInt(curpl[1]) + 1)
					
				}
				break;
			case 3:
				if (curpl[1] == '3')
					nextpl = "p1"
				else {
					nextpl = "p" + (Number.parseInt(curpl[1]) + 1)
					
				}
				break
			case 4:
				if (curpl[1] == '4')
					nextpl = "p1"
				else {
					nextpl = "p" + (Number.parseInt(curpl[1]) + 1)
				}
				break;
			

				
				
		}


		nexp = nextpl.substring(0)

		topcrd=String(topcrd)
//['wild', '+2r', '+4', 'reverser', 'skipr', '1r', '2r', '3r', '4r', '5r', '6r', '7r', '8r', '9r', '+2g',  'reverseg', 'skipg', '1g', '2g', '3g',  '5g', '6g', '7g', '8g', '9g',  '+2b',  'reverseb', 'skipb', '1b', '2b', '3b',  '5b', '6b', '7b', '8b', '9b',  '+2y',  'reversey', 'skipy', '1y', '2y', '3y', '5y', '6y', '7y', '8y', '9y']
		//console.log(result)


		crds213 = JSON.parse(result[result.nextp])
		dards214 = JSON.parse(result[nextpl])

		if (topcrd == 'wild' || topcrd == '+4' || plcard == 'wild') {
			result.firstcard = plcard
			crds213.splice(crds213.indexOf(plcard),1)
			//console.log(crds213)
			//console.log(crds213)
		}
		else if ( plcard == '+4') {
			result.firstcard = plcard
			crds213.splice(crds213.indexOf(plcard),1)

			dards214.push(restcard.pop())
			dards214.push(restcard.pop())
			dards214.push(restcard.pop())
			dards214.push(restcard.pop())
		}
		else if (plcard.substring(0, 2) == '+2') {
			if (topcrd.substring(0, 2) == '+2') {
				console.log(266)
				if (topcrd.substring(0, 2) == '+2') {
					result.firstcard = plcard
					console.log(plcard)
					crds213.splice(crds213.indexOf(plcard), 1)

					dards214.push(restcard.pop())
					dards214.push(restcard.pop())
				}

			}
			else if (plcard[plcard.length - 1] == topcrd[topcrd.length - 1]) {
				result.firstcard = plcard
				crds213.splice(crds213.indexOf(plcard), 1)

				dards214.push(restcard.pop())
				dards214.push(restcard.pop())
			}
			else {
				crd264 = (restcard).pop()
				crds213.push(crd264)

			}

		}
		else if (plcard.includes('reverse')) {
			if (topcrd.includes('reverse')) {
				result.firstcard = plcard
				crds213.splice(crds213.indexOf(plcard), 1)
				//reverse code

			}
			else if (plcard[plcard.length - 1] == topcrd[topcrd.length - 1]) {
				result.firstcard = plcard
				crds213.splice(crds213.indexOf(plcard), 1)
				//reverse code
			}
			else {
				crd264 = (restcard).pop()
				crds213.push(crd264)

			}
		}
		
		else if (plcard.includes('skip')) {
			if (topcrd.includes('skip') || plcard[plcard.length - 1] == topcrd[topcrd.length - 1]) {
				result.firstcard = plcard
				crds213.splice(crds213.indexOf(plcard), 1)
				switch (result.nopl) {

					case 2:
						console.log('heyooo')
						if (nextpl[1] == '2') {
							nextpl = "p1"
							console.log('heyooo')
						}

						else {
							nextpl = "p" + (Number.parseInt(nextpl[1]) + 1)

						}
						break;
					case 3:
						if (nextpl[1] == '3')
							nextpl = "p1"
						else {
							nextpl = "p" + (Number.parseInt(nextpl[1]) + 1)

						}
						break
					case 4:
						if (nextpl[1] == '4')
							nextpl = "p1"
						else {
							nextpl = "p" + (Number.parseInt(nextpl[1]) + 1)
						}
						break;




				}

				console.log(nextpl)
				nexp = nextpl.substring(0)
			}
			else {
				crd264 = (restcard).pop()
				crds213.push(crd264)

			}

		}

		else if (plcard[plcard.length - 1] == topcrd[topcrd.length - 1] || plcard[0] == topcrd[0]) {
			result.firstcard = plcard
			crds213.splice(crds213.indexOf(plcard),1)
		}


		else {
			crd264 = (restcard).pop()
			crds213.push(crd264)
			
		}
		
		result.currentp = result[nexp+"id"]
		result[nextpl] = JSON.stringify(dards214)
		result[result.nextp] = JSON.stringify(crds213)
		result.nextp = nexp
		result.restdeck=JSON.stringify(restcard)
		console.log(result)


		sql = `UPDATE uno2 SET ? WHERE ?? = ?`;
		values = [(result), "roomid", rmid];
		connection.query(sql, values, (err, result) => {
			if (err) {
				console.error('Error updating column:', err);
				return;
			}
			console.log('Column updated successfully');
		});
		res.send("done")
	})
})
	


app.post('/strt', (req, res) => {
	rmid= (req.body.rmid)
	sql = `SELECT * FROM uno2 WHERE ?? = ?`;
	values = ["roomid",rmid];
	console.log(rmid)
	//crds213 = JSON.parse(result[result.nextp])
	connection.query(sql, values, (err, result) => {
		if (err) {
			console.error('Error searching for row:', err);
			return;
		}
		result = result[0]
		//console.log(JSON.parse(crds213))

		result.state = "ingame"

		sql = `UPDATE uno2 SET ? WHERE ?? = ?`;
		values = [result, "roomid", rmid];

		connection.query(sql, values, (err, result) => {
			if (err) {
				console.error('Error updating column:', err);
				return;
			}
			console.log('Column updated successfully');
		});
		res.send("done")
	})
	
		
})

app.post('/chkserv', (req, res) => {
	rmid = req.body.rmid
	userid = req.body.userId
	console.log(rmid)
	sql = `SELECT * FROM uno2 WHERE ?? = ?`;
	values = ["roomid", rmid];

	connection.query(sql, values, (err, result) => {
		if (err) {
			console.error('Error searching for row:', err);
			return;
		}
		result = result[0]

		if (result.state == "pregame")
			res.send({ body: "game hasnt started" })
		else if (result.state == "ingame") {

			data = {
				body:"good",
				firstcard: result.firstcard,
				currentp: result.currentp,
				nextp: result.nextp,
				p1: "",
				p1c: result.p2.split(',').length,
				p2c: result.p1.split(',') .length,
				p3c: result.p3.split(',') .length,
				p4c: result.p4.split(',') .length,
			}
			
			if (result.p1id == userid) {
				data.p1 = result.p1
			}
			else if (result.p2id == userid) {
				data.p1 = result.p2
			}
			else if (result.p3id == userid) {
				data.p1 = result.p3
			}
			else if (result.p4id == userid) {
				data.p1 = result.p4
			}
			console.log(result)
			res.send(data)
		}


	})
})



app.use(express.static('public'))
app.use(express.static('public/large'))
app.listen(port, () => {
    console.log(`Example app listening on port ${port}`)
})







// Insert data into the table































































































//shuffle



function shuffle(n) {
	var cardse = JSON.parse(JSON.stringify(cards))
	switch (n) {
		case 2:
			p1 = []
			p2 = []
			p3 = new Array(52);
			p4 = new Array(52);
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cardse.length)
				a = cardse[c]
				cardse.splice(c, 1)

				p1.push(a)

				d = Math.floor(Math.random() * cardse.length)
				b = cardse[d]
				cardse.splice(d, 1)

				p2.push(b)
			}
			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };
		case 3:
			p1 = [];
			p2 = [];
			p3 = [];
			p4 = new Array(52);
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cardse.length);
				a = cardse[c];
				cardse.splice(c, 1);
				p1.push(a);

				d = Math.floor(Math.random() * cardse.length);
				b = cardse[d];
				cardse.splice(d, 1);
				p2.push(b);

				e = Math.floor(Math.random() * cardse.length);
				f = cardse[e];
				cardse.splice(e, 1);
				p3.push(f);
			}
			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };
		case 4:
			p1 = [];
			p2 = [];
			p3 = [];
			p4 = [];
			for (i = 0; i < 7; i++) {
				c = Math.floor(Math.random() * cardse.length);
				a = cardse[c];
				cardse.splice(c, 1);
				p1.push(a);

				d = Math.floor(Math.random() * cardse.length);
				b = cardse[d];
				cardse.splice(d, 1);
				p2.push(b);

				e = Math.floor(Math.random() * cardse.length);
				f = cardse[e];
				cardse.splice(e, 1);
				p3.push(f);

				g = Math.floor(Math.random() * cardse.length);
				h = cardse[g];
				cardse.splice(g, 1);
				p4.push(h);
			}

			return { "p1": p1, "p2": p2, "p3": p3, "p4": p4 };

	}

}


function shuff(n) {
	var cardse = JSON.parse(JSON.stringify(cards))
	console.log(n)
	plcards = shuffle(n)
	let plc = []
	restdeck = []

	for (i = 0; i < 4; i++) {
		console.log(plcards["p" + (i + 1)].length)
		if (plcards["p" + (i + 1)].length == 7)
			plc = plc.concat(plcards["p" + (i + 1)])
	}

	console.log(plc)
	for (i = 0; (cards.length - plc.length) != restdeck.length;) {

		c = Math.floor(Math.random() * cardse.length);
		randc = cardse[c]

		if (plc.indexOf(randc) == -1 && restdeck.indexOf(randc) == -1) {

			restdeck.push(randc)
			cardse.splice(c, 1)
		}
	}
	firstcard = restdeck.pop()


	return { "plcards": plcards, "restdeck": restdeck, "firstcard": firstcard }
}


console.log(shuff(2))